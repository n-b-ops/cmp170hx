#!/bin/bash
# 256k on one 24 GB card: int4 per-token-head KV cache (experimental).
#
# Trades decode speed for context capacity: TRITON_ATTN + int4 KV serve a
# 314,915-token pool at MAX_LEN=256000 (vs 57,669 for the shipped bf16
# config, 268k for CTX=huge/KVarN) on stock vLLM machinery — no kvarn
# install. Costs ~20% decode vs the FLASH_ATTN bf16 path and the int4
# cache's quality at depth is unmeasured here; see the README section.
# Needs patches/int4-kv-per-token-head.patch (applied by setup like the
# rest of patches/). Profile contributed in PR #42 (@lachhabw).
set -e
# KV_OFFLOAD_GB=N has to become --kv-offloading-size before the allocator default below reads EXTRA_ARGS.
# shellcheck disable=SC1091
source "$(dirname "$(cd "$(dirname "$0")" && pwd)")/launcher_common.sh" \
  || { echo "[alternative] cannot source launcher_common.sh - refusing to boot" >&2; exit 1; }
qwen_normalize_extra_args
qwen_check_bool_knobs
qwen_fa2_fp8kv_single_only alternative.sh
qwen_kv_offload_args
qwen_prefix_cache

if grep -qi microsoft /proc/sys/kernel/osrelease 2>/dev/null || [ -n "${WSL_DISTRO_NAME:-}" ]; then
  ALLOC_DEFAULT=expandable_segments:False
  export VLLM_WSL2_ENABLE_PIN_MEMORY=1
else
  ALLOC_DEFAULT=expandable_segments:True
fi
# The CPU offload tier (--kv-offloading-size in EXTRA_ARGS, or any --kv-transfer-config) is a KV connector, and
# vLLM 0.28 refuses every KV connector under expandable_segments:True unless the cumem allocator is on: the VMM
# allocator can move KV pages out from under the connector's pinned copies. On WSL2 the default above already
# avoids it; on native it is the default, so the tier could not boot with the launcher's defaults (#95).
case " ${EXTRA_ARGS:-} " in
  *"--kv-offloading-size"*|*"--kv-transfer-config"*)
    [ -z "${PYTORCH_CUDA_ALLOC_CONF:-}" ] && [ "$ALLOC_DEFAULT" = expandable_segments:True ] && echo "KV connector in EXTRA_ARGS: PYTORCH_CUDA_ALLOC_CONF=expandable_segments:False (vLLM rejects the connector under VMM; set it explicitly to override)"
    ALLOC_DEFAULT=expandable_segments:False ;;
esac
export PYTORCH_CUDA_ALLOC_CONF=${PYTORCH_CUDA_ALLOC_CONF:-$ALLOC_DEFAULT}
export FLASHINFER_DISABLE_VERSION_CHECK=1
export VLLM_USE_FLASHINFER_SAMPLER=0
export PATH="$PWD/venv/bin:$PATH"
# Same key precedence as the launchers (resolve_api_key.sh): exported
# VLLM_API_KEY wins, api_key.txt is the file fallback, no key = keyless
# boot like start_qwen.sh (previously: hardcoded `cat api_key.txt`).
ALT_DIR="$(cd "$(dirname "$0")" && pwd)"
ALT_REPO="$(dirname "$ALT_DIR")"
REPO="$ALT_REPO"   # resolve_vllm_key reads $REPO/api_key.txt; unset, the file fallback silently finds nothing and the server boots with no key
# shellcheck disable=SC1091
source "$ALT_REPO/resolve_api_key.sh" \
  || { echo "[alternative] cannot source resolve_api_key.sh - refusing to boot with an unknown key" >&2; exit 1; }
# shellcheck disable=SC1091
source "$ALT_REPO/launcher_common.sh" \
  || { echo "[alternative] cannot source launcher_common.sh - refusing to boot" >&2; exit 1; }
resolve_vllm_key
resolve_bind_host
export VLLM_DFLASH2_LOOKUP=${LOOKUP:-1}
# The multi-query 3D verify for the int4 cache (patches/spec-decode-int4-kv-mq3d.patch) was opt-in and nothing
# set it, so this profile ran the stock 2D verify: on a 4090 at 120k, DFlash2 k=7, fresh prefill, decode 43.9 / 26.5 /
# 16.6 tok/s at 24k / 49k / 88k tokens; with it on, 90.4 / 73.7 / 60.2 (and 48.1 at 145k on a 200k boot). Set
# INT4_MQ_3D=0 to get the old path back.
export VLLM_INT4_MQ_3D=${INT4_MQ_3D:-1}
# INT8_ACT=int8: the W4A8 Marlin path for prefill, the same knob start_qwen.sh has (docs/optimizations.md). On this
# profile it lifts fresh prefill +42% at 24k tokens to +13% at 145k (2,765 / 1,884 / 1,246 / 835 tok/s against
# 1,942 / 1,446 / 1,039 / 736 on a 4090, 200k max length). It is a prefill knob: the paired 4090 repro measured
# decode 8 to 13% lower and the KV pool 22% smaller with it on, and the quality trade is the documented int8 one,
# so it stays opt-in here too. INT8_LAYERS narrows it the same way.
INT8_ACT=${INT8_ACT-}
INT8_LAYERS=${INT8_LAYERS-mlp|linear_attn|self_attn}
qwen_int8_exports "$INT8_ACT" "$INT8_LAYERS"

# Ghost regions from a previous OOM-killed server hold host RAM hostage
# (gotcha: 70 restarts of accumulation); same cleanup as start_qwen.sh.
if [ "${VLLM_OFFLOAD_KEEP_SHM:-0}" != 1 ]; then
  for f in /dev/shm/vllm_offload_*.mmap; do
    [ -e "$f" ] || continue
    grep -lqs "$f" /proc/[0-9]*/maps 2>/dev/null || { echo "[alternative] removing stale offload region $f"; rm -f "$f"; }
  done
fi
qwen_kv_offload_shm_check

MODEL=${MODEL:-models/Qwen3.8-27B-W4A16-AutoRound}
DRAFT=${DRAFT:-models/Qwen3.8-27B-DFlash2-W4A16}
# SPEC=dflash2 (default) or SPEC=off. This script used to hardcode the drafter
# and silently ignore SPEC -- PR #46's campaign ran an "A/B" against SPEC=off
# that was really two spec-on arms (the tell: 2.29 emitted tokens per step on
# an arm that must read 1.00). Unrecognized values refuse for the same reason.
SPEC=${SPEC:-dflash2}
case "$SPEC" in
  # draft_sample_method: see start_qwen.sh -- on 0.28 the draft-logits buffer is only
  # allocated when the config asks, and without it acceptance drops ~16% (#73).
  dflash2) SPEC_ARGS=(--speculative-config "{\"method\":\"dflash\",\"model\":\"$DRAFT\",\"num_speculative_tokens\":${DFLASH_TOKENS:-7},\"draft_sample_method\":\"${DRAFT_SAMPLE:-probabilistic}\"}") ;;
  off|none) SPEC_ARGS=() ;;
  *) echo "SPEC=$SPEC is not a mode here: dflash2 (default) or off." >&2; exit 1 ;;
esac
PORT=${PORT:-18020}
# Under WSL2 vLLM sees less than the nominal 24 GiB (22.75 GiB free on a 3090, #401), so 0.95 asks for more
# than exists and the profile fails to start; 0.93 boots and holds the 256k window (446,128-token pool).
# An explicit GPU_UTIL always wins; with a desktop compositor on the card, lower it yourself.
if [ -z "${GPU_UTIL:-}" ] && { grep -qi microsoft /proc/sys/kernel/osrelease 2>/dev/null || [ -n "${WSL_DISTRO_NAME:-}" ]; }; then
  GPU_UTIL=0.93
  echo "WSL detected: GPU_UTIL=0.93 (0.95 exceeds the free memory WSL2 reports; set GPU_UTIL to override)"
fi
GPU_UTIL=${GPU_UTIL:-0.95}
MAX_LEN=${MAX_LEN:-256000}   # 256000 needs the full 0.95 on native Linux; drop MAX_LEN before GPU_UTIL
ATTN_ARGS="--attention-backend TRITON_ATTN --kv-cache-dtype int4_per_token_head"
VISION=${VISION:-0}
ENABLE_THINKING=${ENABLE_THINKING:-false}
DRAFT_TOKENS=${DFLASH_TOKENS:-7}
MAX_SEQS=${MAX_SEQS:-1}

CG=$(( MAX_SEQS * (DRAFT_TOKENS + 1) > 64 ? 64 : MAX_SEQS * (DRAFT_TOKENS + 1) ))
# DFLASH_TOKENS>7 needs the synchronous scheduler, same as start_qwen.sh.
if [ "$DRAFT_TOKENS" -gt 7 ]; then ASYNC_SCHED=${ASYNC_SCHED:-0}; else ASYNC_SCHED=${ASYNC_SCHED:-1}; fi

qwen_vision_args

# With the drafter on, pass the retention interval explicitly: 0.30's unset default is 0 (the replay
# boundaries only), where 0.29 resolved it to dense (vllm #55760); start_qwen.sh has the measurement.
# The default here depends on a KV tier (the connector check above): without one it is 0, because at dense two
# ~60K conversations on this int4 pool evicted each other completely (0 / 0 cached where 0 held 93.5% for both);
# with one it is None (dense), which the tier serves from (gotcha 60). PREFIX_RETENTION sets it (0 = boundaries
# only, empty = dense); the flag in EXTRA_ARGS wins.
if [ "$PREFIX_CACHE_ON" = 1 ] && [ "$SPEC" = dflash2 ]; then
  case " ${EXTRA_ARGS:-} " in
    *"--prefix-cache-retention-interval"*) ;;
    *)
      case " ${EXTRA_ARGS:-} " in
        *"--kv-offloading-size"*|*"--kv-transfer-config"*) R_DEFAULT=None ;;
        *) R_DEFAULT=0 ;;
      esac
      if [ "${PREFIX_RETENTION+set}" = set ]; then R=${PREFIX_RETENTION:-None}; else R=$R_DEFAULT; fi
      EXTRA_ARGS="--prefix-cache-retention-interval $R ${EXTRA_ARGS:-}" ;;
  esac
fi

# Array, not $( ... || echo ... ): the fallback makes it errexit-safe, but an
# unquoted expansion still word-splits; match SPEC_ARGS/METRICS_ARGS.
ASYNC_ARGS=(--no-async-scheduling)
[ "$ASYNC_SCHED" = 1 ] && ASYNC_ARGS=(--async-scheduling)

# REQ_METRICS=1: per-request timing fields + usage on every response (issue #51).
# Not with --disable-log-stats (the timing fields need the engine-stats path).
# Array, not $( [ ] && echo ): the command substitution exits 1 when the test
# is false, which under `set -e` killed this script silently (#59).
METRICS_ARGS=()
if [ "${REQ_METRICS:-0}" = 1 ]; then
  # vLLM 0.29.0: per-request speculative-decoding acceptance metrics ride in the response under
  # metrics.speculative_decoding (n == 1 only; the field is experimental, shape as of v0.29.0). summary
  # is mean acceptance length, draft acceptance rate and the step histogram; REQ_METRICS_DETAILED=1
  # adds the ordered per-step accepted/proposed arrays, which upstream says is not free, so it is a
  # separate opt-in and off in every profile anyone benchmarks (#66, #75, gotcha 53).
  SPEC_METRICS=summary; [ "${REQ_METRICS_DETAILED:-0}" = 1 ] && SPEC_METRICS=detailed
  METRICS_ARGS=(--enable-per-request-metrics --enable-force-include-usage
                --per-request-spec-decode-metrics "$SPEC_METRICS")
fi

qwen_exec vllm serve "$MODEL" \
  --served-model-name qwen3.8-27b \
  --host $BIND_HOST --port $PORT \
  --gpu-memory-utilization $GPU_UTIL \
  --max-model-len $MAX_LEN \
  --max-num-seqs $MAX_SEQS \
  --api-server-count 1 \
  "${VISION_ARGS[@]}" \
  ${ATTN_ARGS} \
  --mamba-ssm-cache-dtype float16 \
  "${ASYNC_ARGS[@]}" \
  --max-num-batched-tokens 2048 \
  "${SPEC_ARGS[@]}" \
  --compilation-config "{\"max_cudagraph_capture_size\":$CG,\"custom_ops\":[\"+rms_norm\",\"+silu_and_mul\"]}" \
  --reasoning-parser qwen3 \
  --enable-prompt-tokens-details \
  "${METRICS_ARGS[@]}" \
  --enable-auto-tool-choice --tool-call-parser qwen3_coder \
  --tool-strict-level "${TOOL_STRICT:-parameter}" \
  --default-chat-template-kwargs "{\"enable_thinking\": $ENABLE_THINKING}" \
  ${EXTRA_ARGS}
